import React, { useState, useEffect } from 'react';

const FlightsList = () => {
  const [flights, setFlights] = useState([]);
  const getAllFlights = () => {
    fetch('http://localhost:555/flights')
      .then((response) => {
        if (response.ok) {
          return response.json();
        } else {
          console.error('Failed to fetch flights');
          return [];
        }
      })
      .then((data) => {
        setFlights(data);
      })
      .catch((error) => {
        console.error('Error fetching flights:', error);
      });
  };

  useEffect(() => {
    getAllFlights();
  }, []);

  return (
    <div className="form-section">
      <h3>View All Flights</h3>
      <button onClick={getAllFlights}>Get Flights</button>
      <ul>
        {flights.map((flight) => (
          <li key={flight.ID}>
            {flight.HOME} to {flight.AWAY} on {flight.DATE} (Seats: {flight.QUANTITY})
          </li>
        ))}
      </ul>
    </div>
  );
};

export default FlightsList;
