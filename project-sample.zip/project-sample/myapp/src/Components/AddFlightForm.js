import React, { useState } from 'react';

const AddFlightForm = () => {
  const [origin, setOrigin] = useState('');
  const [destination, setDestination] = useState('');
  const [date, setDate] = useState('');
  const [quantity, setQuantity] = useState('');
  const [message, setMessage] = useState(''); 

  const addFlight = () => {
    fetch('http://localhost:555/flights/addflight', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({home:origin,away:destination, date, quantity }), 
      credentials:"include"
    })
    .then((response) => {
      if (!response.ok) {
        throw new Error(`Failed to add flight. status code ${response.status}, message
          ${JSON.stringify(response.text())}`);
      }
      setMessage('Flight added successfully');
      alert('Flight added successfully'); 
    })
    .catch((error) => {
      setMessage(`Error: ${error.message}`); 
      alert(error.message); 
    });
  };
  return (
    <div className="form-section">
      <h3>Add Flight (Admin)</h3>
      <form>
        <input 
          type="text" 
          placeholder="Origin" 
          value={origin} 
          onChange={(e) => setOrigin(e.target.value)} 
          required 
        /><br />
        <input 
          type="text" 
          placeholder="Destination" 
          value={destination} 
          onChange={(e) => setDestination(e.target.value)} 
          required 
        /><br />
        <input 
          type="date" 
          value={date} 
          onChange={(e) => setDate(e.target.value)} 
          required 
        /><br />
        <input 
          type="number" 
          placeholder="Quantity" 
          value={quantity} 
          onChange={(e) => setQuantity(e.target.value)} 
          required 
        /><br />
        <button type="button" onClick={addFlight}>Add Flight</button>
      </form>
      {message && <p>{message}</p>} 
    </div>
  );
};

export default AddFlightForm;
